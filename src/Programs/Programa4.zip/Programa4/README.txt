Montaño Pérez Joshua Said 
317222812
Practica 04: Bosque generador

Debemos de estar en la primera carpeta src
Para compilar el programa es necesario:
 javac -cp . src/*.java
Para correr el Programa :
 java -cp . src.KruskalMain prueba.txt
