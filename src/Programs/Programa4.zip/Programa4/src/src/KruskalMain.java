package src;
import java.util.Comparator;
import java.util.Scanner;
import java.io.File;
import java.util.PriorityQueue;
/**
 * Clase que modela el algoritmo Kruskal
 */
public class KruskalMain{

  public static class AnalizaPesos implements Comparator<String>{

  @Override
  public  int compare(String i1,String i2){
    String[] p1 = i1.split(",");
    String[] p2 = i2.split(",");
    int valor1 = Integer.parseInt(p1[2]);
    int valor2 = Integer.parseInt(p2[2]);

    if(valor1 < valor2) return -1  ;

    if(valor2 > valor1) return 1 ;

    return 0 ;
    }
  }

public static void main(String[] args) {
  try{
    String name = args[0] ;
    File l = new File(name);
    Scanner s = new Scanner(l);
    int numAristas = -1;

    while(s.hasNext()){
      numAristas = numAristas+1;
      s.nextLine();
    }

    Scanner sv = new Scanner(l);
    String line = sv.nextLine();
    String[] arrV = line.split(",");
    int[] v = new int[arrV.length];
    int contador = 0;
    int  numVert = v.length;
    int k = 0;

    while(k < numVert){
      v[k] = Integer.parseInt(arrV[k]);
      contador++;
      k++;
    }
    sv.close();
    System.out.println("Numero de vertices: "+ numVert);
    System.out.println("Numero de aristas "+numAristas);

    Disjointset conjunto = new Disjointset(numVert);
    int  cI = 0 ;
    while(cI < numVert-1){
      conjunto.llenar(v[cI]);
      cI ++ ;
    }

    Comparator<String> comparaPeso = new AnalizaPesos();
    PriorityQueue<String> cola = new PriorityQueue<>(numAristas, comparaPeso);

    Scanner  sgraph = new Scanner (l);
    String vG = sgraph.nextLine();
    
    System.out.println("Vertices de la grafica: "+ vG+".");
    System.out.println("Aristas de la grafica: ");
    String arista_i ;
    while(sgraph.hasNext()){
       arista_i = sgraph.nextLine();
       System.out.println(arista_i);
       cola.add(arista_i);
    }
    System.out.println(" ");
    int kG = 0 , kE = 0 , n = 0 ;
    System.out.println("Aristas de nuestro bosque:");

    while(!cola.isEmpty() && kE < numVert-1){
      String arista = cola.remove();
      String [] arrElems = arista.split(",");
      int v_i = Integer.parseInt(arrElems[0]);
      int v_f = Integer.parseInt(arrElems[1]);
      int pesoA =  Integer.parseInt(arrElems[2]);
      int a1 = conjunto.buscaV(v_i);
      int a2 =  conjunto.buscaV(v_f);
      if (a1 != a2){
        n++ ;
        System.out.println("A("+n+") =======> "+arista);
        System.out.println(" ");
        System.out.println("VI: "+v_i+" VF:  "+v_f+" peso : "+pesoA);
        kG = kG + pesoA;
        conjunto.union(v_i,v_f);
        kE++ ;
      }
    }
    System.out.println("Costo total del arbol generador de peso mínimo: "+kG+".");
    s.close();
    sgraph.close();
    }catch(Exception e){
    System.out.println(e);
    }
  }
}
