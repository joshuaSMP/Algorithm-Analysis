package src;

public class Disjointset{
  private int c [] ;
  private int rango [] ;


  public Disjointset(int n){
      this.c = new int[n+1];
      this.rango = new int[n+1];
  }

  public Disjointset(int [] r, int [] s){
    this.c = r ;
    this.rango =  s ;
  }

  public void llenar(int v){
    this.c[v] =  v ;
  }

  public int  buscaV (int v){
    return (this.c[v] ==  v) ? v : this.buscaV(this.c[v]) ;
  }

  public void union (int v, int u){
    int a1 = this.buscaV(v);
    int a2 = this.buscaV(u);
    if(this.rango[a1] < this.rango[a2])
      this.c[a1] = a1 ;
    else if (this.rango[a1] > this.rango[a2]){
      this.c[a2] = a1 ;
          }else{
            this.c[a2] = a1 ;
            this.rango[v] +=1 ;
                }
  }
}
