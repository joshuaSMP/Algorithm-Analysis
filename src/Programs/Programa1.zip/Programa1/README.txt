El programa se compila: javac Grafica.java 
y para correrlo es: java Grafica prueba.txt

Una disculpa acab de revisar que subi el pdf de la tarea en vez del zip de la practica ;(