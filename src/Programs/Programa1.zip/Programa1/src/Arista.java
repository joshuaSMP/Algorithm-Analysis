/**
 * Clase que modela una arista de una gráfica
 * @author Montaño Pérez Joshua Said 
 */
public class Arista {
    //Atributos
    private Vertice primero;

    private Vertice segundo;

    public Arista(Vertice verUno, Vertice verDos){
        this.primero = verUno;
        this.segundo = verDos;
    }
    /**
     * Metodo que nos regresa el valor de primero
     * @return
     */
    public Vertice getPrim(){
        return primero;
    }
    /**
     * Metodo que nos regresa el valor de segundo
     * @return
     */
    public Vertice getSeg() {
        return segundo;
    }

    @Override
    public String toString(){
        return "(" + primero.toString() + ", " + segundo.toString() + ")";
    }
    
    public Boolean equals(Arista a){
        return (this.primero.equals(a.primero)) && (this.segundo.equals(a.segundo));
    }
}
