import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

/**
 *Clase que modela una grafica 
 @author Montaño Pérez Joshua Said 
 */
public class Grafica<T> {
    
    private LinkedList<Vertice<T>> verti;

    private LinkedList<Arista> aris;

    public Grafica(){
       this.verti = new LinkedList<Vertice<T>>();
       this.aris = new LinkedList<Arista>();
    }

    public Grafica(LinkedList<Vertice<T>> ver, LinkedList<Arista> ari) {
        this.verti = (LinkedList<Vertice<T>>)ver.clone();
        this.aris = (LinkedList<Arista>) ari.clone();
    }

    public void vertice(Vertice<T> ver){
        verti.add(ver);
    }

    public void arista(Vertice<T> ver1, Vertice<T> ver2){
        aris.add(new Arista(ver1, ver2));
    }

    public Boolean esArista(Vertice<T> ver1, Vertice<T> ver2){
        for (Arista a : aris) {
            if(a.getPrim().equals(ver1) && a.getSeg().equals(ver2)){
                return true;
            }
        }

        return false;
    }

    public Boolean esVertice(Vertice<T> ver) {

        for (Vertice<T> vertice : verti) {
            if(vertice.equals(ver)){
                return true;
            }
        }

        return false;
    }

    public LinkedList<Vertice<T>> vecino(Vertice<T> ver){
        LinkedList<Vertice<T>> vecinosRes = new LinkedList<>();

        vecinosRes.add(ver);

        for(Arista a : aris){
            if(a.getPrim().equals(ver)){
                vecinosRes.add(a.getSeg());
            }
        }

        return vecinosRes;
    }

    public Grafica<T> graficaBuena(){
        Grafica<T> uno = new Grafica<T>(this.verti, this.aris);

        Vertice<T> dos = uno.verti.getFirst();

        LinkedList<Vertice<T>> vecinosRes = vecino(dos);

        for (Vertice<T> neighbor : vecinosRes) {
            uno.verti.remove(neighbor);
        }

        for (Arista ari : this.aris) {
            if(!uno.verti.contains(ari.getPrim()) || !uno.verti.contains(ari.getSeg())){
                uno.aris.remove(ari);
            }
        }

        return uno;
    }

    public Boolean esIndependiente(LinkedList<Vertice<T>> ver){
        for (Vertice<T> ver1 : ver) {
            for (Vertice<T> ver2 : ver) {
                if(esArista(ver1, ver2))
                    return false;
            }
        }

        return true;
    }

    public LinkedList<Vertice<T>> elConIndependiente(){
        return conIndependiente(this);
    }

    private LinkedList<Vertice<T>> conIndependiente(Grafica<T> diG){

        if(diG.verti.size() == 0){
            return new LinkedList<Vertice<T>>();
        }

        Vertice<T> uno = diG.verti.getFirst();
        Grafica<T> dos = diG.graficaBuena();
        LinkedList<Vertice<T>> indep = (LinkedList<Vertice<T>>)dos.verti.clone();

        if(dos.verti.size() <= 3){
            for (int i = 0; i < indep.size(); i++) {
                for (int j = 0; j < indep.size(); j++) {
                    if(dos.esArista(indep.get(i), indep.get(j))){
                        indep.remove(j);
                        i = 0;
                        j = 0;
                    }
                }
            }
        }

        if(indep.size() > 3){
            indep = conIndependiente(dos);
        }
        
        indep.add(uno);
        
        if(diG.esIndependiente(indep)){
            return indep;
        }

        indep.remove(uno);

        for (Vertice<T> w : dos.verti) {
            if(diG.esArista(w, uno) && !indep.contains(w)){
                indep.add(w);
                break;
            }
        }

        return indep;
    }

    public Boolean equals(Grafica<T> g){
        return (this.verti.equals(g.verti)) && (this.aris.equals(g.aris));
    }

    
    public static void main(String[] args) {
        
        if (args.length != 1) {
            System.err.println("Uso:  java Main <archivo>");
            System.exit(1);
        }

        Grafica<String> gra = new Grafica<String>();
        String file = args[0];


            BufferedReader reader;
            try {
                reader = new BufferedReader(new FileReader(file));
                String line = reader.readLine();
    
                String[] ver = line.split(",");
    
                
                String[] arista;
                Vertice<String> ver1 = null;
                Vertice<String> ver2 = null;
    
                int lineCounter = 0;
    
                for (String v : ver) {
    
                    ver1 = new Vertice<String>(v);
    
                    if (!gra.esVertice(ver1)) {
                        gra.vertice(ver1);
                    }
                }
    
                while ((line = reader.readLine()) != null) {
    
                    ver1 = null;
                    ver2 = null;
    
                    arista = line.split(",");
    
                    if (arista.length != 2) {
                        reader.close();
                        throw new IllegalArgumentException(" - Linea " + lineCounter + ": " + line);
                    }
    
                    for (Vertice<String> vert : gra.verti) {
                        if (vert.equalsvalor(arista[0])) {
                            ver1 = vert;
                            break;
                        }
                    }
    
                    for (Vertice<String> vert : gra.verti) {
                        if (vert.equalsvalor(arista[1])) {
                            ver2 = vert;
                            break;
                        }
                    }
    
                    if (ver1 == null || ver2 == null) {
                        reader.close();
                        throw new IllegalArgumentException(" - Linea " + lineCounter + ": " + line);
                    }
    
                    gra.arista(ver1, ver2);
    
                }
    
                reader.close();
    
         
            } catch (IOException err) {
                System.err.println("Error al leer el archivo...");
                System.exit(2);
            }
        System.out.println("El conjunto independiente es: " + gra.elConIndependiente().toString());

        System.exit(0);
    }
}
