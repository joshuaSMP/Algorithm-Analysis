/**
 * Clase que modela los vertices de una grafica.
 * @author Montaño Pérez Joshua Said
 */
public class Vertice<T> {

    private T valor;

    /**
     * Contructor para un {@code Vertice}.
     * 
     * @param valor valor del vértice.
     */
    public Vertice(T valor){
        this.valor = valor;
    }

    /**
     * Regresa una representación en {@code String} del {@code Vertice}.
     * 
     * @return La representación del vértice.
     */
    @Override
    public String toString() {
        return valor.toString();
    }

    /**
     * Compara el valor del {@code Vertice} con un valor dado.
     * 
     * @param valor El valor con el cuál comparar.
     * @return {@code true} si el valor del {@code Vertice} es equivalente
     *         al valor dado, {@code false} en otro caso.
     */
    public Boolean equalsvalor( T valor){
        return this.valor.equals(valor);
    }
    
    /**
     * Compara el {@code Vertice} con otro {@code Vertice} dado.
     * 
     * @param vertice El {@code Vertice} con el cuál comparar.
     * @return {@code true} si el {@code Vertice} es equivalente
     *         al {@code Vertice} dado, {@code false} en otro caso.
     */
    public Boolean equals(Vertice<T> v){
        return this.valor.equals(v.valor);
    }
}