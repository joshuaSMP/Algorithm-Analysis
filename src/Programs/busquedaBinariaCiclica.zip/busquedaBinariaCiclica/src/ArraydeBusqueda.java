package src;
import java.util.Random;
import java.lang.Math;

/**
 * @autor Montaño Pérez Joshua Said
 */

public class ArraydeBusqueda{
  private int arreglo [] ;
  private int n ;
  private int rango ;

  public ArraydeBusqueda(int n, int rango ){
    this.rango = rango ;
   
    this.arreglo = new int [n];
    this.n = n;

    Random random = new Random();
    this.arreglo[0] = random.nextInt(rango);
    int max = this.arreglo[0]+1 ;
    int min = this.arreglo[0]-1 ;
    for(int i = 1; i<this.n;i++){
      this.arreglo[i] = (int)Math.floor(Math.random()*(max-min+1)+min);
      max = this.arreglo[i]+1;
      min = this.arreglo[i]-1 ;
    }
      if(this.arreglo[0]>= this.arreglo[n-1]){
      int  i = this.n-1 ;
      int centinel = this.n-1  ;
      while( i >= 0 ){
        if(this.arreglo[i] >= this.arreglo[0] && i != 0 ){
          centinel = i ;
          break ;
        }
          i--;
      }
      int m1 = this.arreglo[centinel]+1 ;
      int m2 = this.arreglo[centinel] ;

      for(int j =  centinel; j<this.n ;j++){
        this.arreglo[j] = (int)Math.floor(Math.random()*(m1-m2+1)+m2);
        max = this.arreglo[j]+1;
        min = this.arreglo[j]-1 ;
      }
    }
    if (this.arreglo[0] == this.arreglo[n-1])
      this.arreglo[n-1] +=1 ;
  }


  public ArraydeBusqueda(int arreglo[] ){
    this.arreglo =arreglo;
    this.n = arreglo.length ;

  }

  public void setArray(int newArr[]){
    this.arreglo = newArr;
    this.n = arreglo.length ;

  }

  public int getRango(){
    return this.rango ;
  }

  public void setRango(int rangoN){
    this.rango = rango ;
  }
  
  public int[] getArr(){
    return this.arreglo;
  }

  public void setArr(int[] arrN){
    this.arreglo = arreglo;
  }

  public int getlongArr(){
    return this.n;
  }

  public void setLongetArr(int n){
    this. n = n;
  }

  public int getElement(int i){
    return this.arreglo[i];
  }

  public void setElem(int i){
    this.arreglo[i] = arreglo[i];
  }

  public boolean validaElArray(){
    int i = 0 ;
    while (i<this.n-1){
      if(Math.abs(this.arreglo[i] -this.arreglo[i+1])>1){
        return false;
      }
      i++;
    }
    if(this.arreglo[0]>= this.arreglo[this.n-1]) return false ;
    return true ;
  }

  public int[] maxvalA(){
    int i =  0 ;
    int res[] = new int [2];
    res[0] = this.rango;
    while(i < this.n){
      if(res[1]<this.arreglo[i]) res[1] = this.arreglo[i];
      if(res[0]>this.arreglo[i]) res [0] = this.arreglo[i];
      i++ ;
    }
    return res ;
  }


  public int busqueda(int z){
    int min = this.n -1 ;
    int max = 0 ;
    int def = this.arreglo[n-1]-this.arreglo[0];
    int med = this.n/2   ;
    int contador = 0  ;
    int mid ;

    while(max != min ){
      if(contador >= ((int)(Math.log(this.n) / Math.log(2)))) break ; //la primera busqueda a lo mas hará log n iteraciones de no ser el caso, z no esta en esa mitad
      max += Math.abs (z-arreglo[max]);
      min -= Math.abs(z-arreglo[min]);
      mid = (max +min)/2 ;
      if(this.arreglo[mid] == z ) return mid ;
      else if(z< this.arreglo[mid]) min = mid -1 ;
      else max = mid +1 ;
      contador ++ ;
    }

    if (max != z){
      int mid_2 ;
      int izq = (this.n/2) ;
      int der = this.n-1 ;
      while(izq <= der){
        mid_2 =izq + (der - izq) / 2;
        if(this.arreglo[mid_2] == z) return mid_2;
        if(this.arreglo[mid_2]< z)
          izq = mid_2 +1 ;
        else
          der = mid_2 -1 ;
      }
    }
    return max;

  }

  public String toString(){
      StringBuilder subRes = new StringBuilder();
      subRes.append("[");
      for(int i = 0;i<this.n;i++){
        subRes.append(this.arreglo[i]);
        if(i != this.n-1){
          subRes.append(",");
        }
      }
      subRes.append("]");
        return subRes.toString();
  }
}
