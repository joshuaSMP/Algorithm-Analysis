package src;
import java.util.Random;

public class Tests{
  public static void main(String[] args) {
      System.out.println("Prueba de busqueda");
      int res = -1 ;
  
      System.out.println("Caso 1 ");
      int ar1 [] = {80,80,80,79,79,79,80,79,79,79,79,79,79,78,78,79,80,80,80,81};
      int zt1 = 78 ;
      ArraydeBusqueda testb1 = new ArraydeBusqueda(ar1);
      System.out.println(testb1.toString());
      System.out.println("Elemento a buscar: "+" "+zt1);
      res = testb1.busqueda(zt1);
      if (res == 13 || res == 14 )
        System.out.println("La busqueda es correcta");
      else
        System.out.println("La busqueda es incorrecta");
      
      System.out.println("------------------------------------------------------------------");
      System.out.println("Caso 2 ");
      int ar2 [] = {17,17,17,17,17,16,17,17,16,16,16,16,16,17,16,16,16,17,16,17};
      zt1 = 16 ;
      ArraydeBusqueda testb2 = new ArraydeBusqueda(ar2);
      System.out.println(testb2.toString());
      System.out.println("Elemento a buscar: "+" "+zt1);
  
      res = testb2.busqueda(zt1);
      if (res == 0 || res == 6 || (res >=9 && res < 13) || (res >=14 && res <17) || res == 18 )
        System.out.println("La busqueda es correcta");
      else
        System.out.println("La busqueda es incorrecta");
  
    System.out.println("------------------------------------------------------------------");
    System.out.println("Caso 3:");
     int ar3 [] ={1,5,4,3,2};
     zt1 = 1;
     ArraydeBusqueda testb3 = new ArraydeBusqueda(ar3);
     System.out.println(testb3.toString());
     System.out.println("Elemento a buscar: "+" "+zt1);
     res = testb3.busqueda(zt1);
     if(res == 0)
       System.out.println("La busqueda es correcta");
     else
       System.out.println("La busqueda es incorrecta");
       
    System.out.println("------------------------------------------------------------------");
    System.out.println("Caso 4: ");
    int ar4 [] ={3,2,1,2,3,4,4,4,5,6};
    zt1 = 6 ;
    ArraydeBusqueda testb4 = new ArraydeBusqueda(ar4);
    System.out.println(testb4.toString());
    System.out.println("Elemento a buscar: "+" "+zt1);
    res = testb4.busqueda(zt1);
    if(res == 9)
        System.out.println("La busqueda es correcta");
    else
        System.out.println("La busqueda es incorrecta");
  
  
  
  }
    }
  