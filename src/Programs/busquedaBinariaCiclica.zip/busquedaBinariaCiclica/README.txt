Montaño Pérez Joshua Said
317222812
Tienen que estar afuera de la carpeta src para poder compilar y jalar este programas 
Este programa se compila con:
javac -cp . src/*.java

Este programa se corre con:
java -cp . src.Tests
