
/**
 * @author Montaño Pérez Joshua Said
 * num cuenta 317222812 
 */
public class Main {
	
	//Instancia Adoquin.
    private final static Adoquin ejemplo = new Adoquin(4, 4, 4);
	
	/**
	 * Entrada de la aplicación.
	 * @param args Parámetros de entrada.
	 */
	public static void main(String[] args) {
		ejemplo.adoquinar();
	}
}