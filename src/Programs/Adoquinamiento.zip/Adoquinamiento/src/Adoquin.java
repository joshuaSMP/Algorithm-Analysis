/**
 * @author Montaño Pérez Joshua Said
 * num cuenta 317222812 
 */
public class Adoquin {

	//Tablero de adoquinamiento
	private int[][] tablero;
	//Posición del cuadrado
	private int i;
	private int j;
	
	/**
	 * Genera una región R de tamaño m x m donde m = 2 ^ k.
	 * Se marca la posición i j como el "cuadrado especial".
	 * @param k La potencia de 2 ^ k >= 0.
	 * @param i La fila del cuadrado especial. 0 <= i < m.
	 * @param j La columna del cuadrado especial. 0 <= j < m.
	 */
	public Adoquin(int k, int i, int j){
		tablero = new int[1 << k][1 << k]; //1 << k = 2 ^ k
		this.i = i;
		this.j = j;
	}

	/**
	 * Adoquina la región.
	 * Imprime el resultado en la consola con el toString
	 */
	public void adoquinar(){
		adoquinar(0, tablero.length - 1, 0, tablero.length - 1, i, j);
		System.out.println(toString());
	}
	
	/*
	 * Método recursivo para adoquinar la tablero
	 * El intervalo del tablero actual es [inicioI, finalI] x [inicioJ, finalJ].
	 * El cuadrado especial está en la posición (especialI,especialJ).
	 */
	private void adoquinar(int inicioI, int finalI, int inicioJ, int finalJ, int especialI, int especialJ){
		if (finalI == inicioI) return; 
		if (finalI == inicioI + 1) { 
			if (especialI == inicioI)
				tablero[finalI][inicioJ] = ++tablero[finalI][finalJ];
			else
				tablero[inicioI][inicioJ] = ++tablero[inicioI][finalJ];
			if (especialJ == inicioJ)
				++tablero[especialI][finalJ];
			else
				++tablero[especialI][inicioJ];
		} else {
			int midI = (inicioI + finalI - 1)/2;
			int midJ = (inicioJ + finalJ - 1)/2;
			int i1, i2, i3, i4;
			int j1, j2, j3, j4;
			if (especialI > midI) {
				if (especialJ > midJ) {
					tablero[midI][midJ] = tablero[midI + 1][midJ] = ++tablero[midI][midJ + 1];
					i1 = midI;
					i2 = midI;
					i3 = midI + 1;
					i4 = especialI;
					j1 = midJ;
					j2 = midJ + 1;
					j3 = midJ;
					j4 = especialJ;
				} else { 
					tablero[midI][midJ] = tablero[midI + 1][midJ + 1] = ++tablero[midI][midJ + 1];
					i1 = midI;
					i2 = midI;
					i3 = especialI;
					i4 = midI + 1;
					j1 = midJ;
					j2 = midJ + 1;
					j3 = especialJ;
					j4 = midJ + 1;
				}
			} else {
				if (especialJ > midJ) { 

					tablero[midI][midJ] = tablero[midI + 1][midJ] = ++tablero[midI + 1][midJ + 1];
					//Posición de los cuadrados especiales para la llamada recursiva.
					i1 = midI;
					i2 = especialI;
					i3 = midI + 1;
					i4 = midI + 1;
					j1 = midJ;
					j2 = especialJ;
					j3 = midJ;
					j4 = midJ + 1;
				} else { 
					tablero[midI + 1][midJ] = tablero[midI + 1][midJ + 1] = ++tablero[midI][midJ + 1];
					//Posición de los cuadrados especiales para la llamada recursiva.
					i1 = especialI;
					i2 = midI;
					i3 = midI + 1;
					i4 = midI + 1;
					j1 = especialJ;
					j2 = midJ + 1;
					j3 = midJ;
					j4 = midJ + 1;
				}
			}
			adoquinar(inicioI, midI, inicioJ, midJ, i1, j1);
			adoquinar(inicioI, midI, midJ + 1, finalJ, i2, j2); 
			adoquinar(midI + 1, finalI, inicioJ, midJ, i3, j3); 
			adoquinar(midI + 1, finalI, midJ + 1, finalJ, i4, j4); 
		}
	}
	/**
	 * Imprime el tablero como una matriz de m x m.
	 */
	@Override public String toString(){
		String regionS = "";
		for(int n = 0; n < tablero.length; n++){
			for(int m = 0; m < tablero.length; m++)
				regionS += tablero[n][m] + " ";
			regionS += "\n";
		}
		return regionS;
	}
}