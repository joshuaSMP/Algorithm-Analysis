Alumno: Montaño Pérez Joshua Said 317222812

se debe compilar adrentro del src 
compilando solo el Main
javac Main.java
luego corriendo el programa
java Main

la explicacion de terminal es que el caracter 0 es el cuadro especila y conforma ese cuaro especial
se va construyendo el adonquinamiento en "L".

